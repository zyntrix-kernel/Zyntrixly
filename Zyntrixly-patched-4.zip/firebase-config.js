// ════════════════════════════════════════════════
//  ZYNTRIXLY — firebase-config.js
//  IMPORTANT: Add this file to .gitignore before
//  open-sourcing. Provide firebase-config.example.js
//  with placeholder values for GitHub.
// ════════════════════════════════════════════════
const firebaseConfig = {
  apiKey:            "AIzaSyADe7-8VV6flXLwRc3pQtVpallWScxbY90",
  authDomain:        "zyntrixly.firebaseapp.com",
  projectId:         "zyntrixly",
  storageBucket:     "zyntrixly.firebasestorage.app",
  messagingSenderId: "663603557838",
  appId:             "1:663603557838:web:634138b6999cf849d5e79f"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db   = firebase.firestore();

db.enablePersistence({synchronizeTabs:true}).catch(err=>{
  console.warn('Firestore persistence unavailable:',err?.code||err);
});
// Notify deferred boot loader
window.dispatchEvent(new Event('firebase-ready'));
