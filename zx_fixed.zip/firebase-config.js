// ════════════════════════════════════════════════
//  ZYNTRIXLY — firebase-config.js  (LOCAL DEV)
//  ⚠️  GITIGNORED — never commit this file.
//  Boot loader in index.html reads firebase.apps
//  after this runs and grabs auth/db from there.
// ════════════════════════════════════════════════
const firebaseConfig = {
  apiKey:            "AIzaSyADe7-8VV6flXLwRc3pQtVpallWScxbY90",
  authDomain:        "zyntrixly.firebaseapp.com",
  projectId:         "zyntrixly",
  storageBucket:     "zyntrixly.firebasestorage.app",
  messagingSenderId: "663603557838",
  appId:             "1:663603557838:web:634138b6999cf849d5e79f"
};
// Only init if not already done (prevents duplicate-app crash)
if (!firebase.apps || !firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}
// Boot loader grabs window.auth / window.db after this script runs
